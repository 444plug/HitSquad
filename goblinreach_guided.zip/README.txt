GoblinReach Guided Login Extension (Manifest V3)
------------------------------------------------
Buttons:
- Open Instagram
- Check Login (detects if you're logged in without reading cookies)
- Inject "Installed" Banner (visual test)
- Optional license key storage (chrome.storage.local)

Install:
1) Download goblinreach_guided.zip
2) Unzip it
3) chrome://extensions → Developer Mode ON
4) Load unpacked → select the UNZIPPED folder (the one with manifest.json)