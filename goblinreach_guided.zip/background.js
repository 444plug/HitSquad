chrome.runtime.onInstalled.addListener(() => {
  console.log('GoblinReach Guided Login installed.');
});