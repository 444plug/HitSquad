async function sendToActiveTab(message) {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  if (!tab?.id) { alert('Open a tab first.'); return; }
  return chrome.tabs.sendMessage(tab.id, message);
}

document.getElementById('inject').addEventListener('click', async () => {
  try {
    const res = await sendToActiveTab({cmd: 'injectBanner'});
    console.log('Injected:', res);
  } catch(e){ console.warn(e); alert('Could not inject. Make sure a page is open (not chrome://).'); }
});

document.getElementById('save').addEventListener('click', async () => {
  const u = document.getElementById('u').value.trim();
  const p = document.getElementById('p').value;
  await chrome.storage.local.set({ demoCreds: { u, p }});
  alert('Saved locally (demo).');
});