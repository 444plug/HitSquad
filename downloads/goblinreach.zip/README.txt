Placeholder extension.
Replace this file with your real goblinreach.zip when ready.
