GoblinReach Demo Extension (Manifest V3)
---------------------------------------
This is a minimal demo so you can verify the website download + Chrome install flow.

Files:
- manifest.json        -> Chrome extension manifest (v3)
- background.js        -> Minimal background service worker
- content.js           -> Injects a small banner when commanded
- popup.html / popup.js-> Popup UI with two buttons

How to install (Chrome):
1) Download goblinreach.zip from your website.
2) Unzip it on your computer.
3) Open chrome://extensions
4) Enable "Developer mode" (top-right).
5) Click "Load unpacked" and select the UNZIPPED folder (the one with manifest.json).
6) Click the extension icon in Chrome -> Pin it -> Click and press "Inject" to see the banner.

Replace these demo files with your real extension files when ready.